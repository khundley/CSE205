//******************************************************************************
// ABSTRACT CLASS: Amphibian (Amphibian.Java)
//
// DESCRIPTION
// Amphibian is the abstract superclass for all Amphibian subclasses.
// TEAM: 5
// AUTHORS:
//    ANDREW BRAND   | ABRAND3  | A.BRAND101691@YAHOO.COM
//    KENYON HUNDLEY | KHUNDLEY | KENYONHUNDLEY@YAHOO.COM
//    ISAIAH POTTS   | IPOTTS1  | ZAHPOTTS123@GMAIL.COM
//    ANTHONY SPAUGH | ASPAUGH  | ASPAUGH@ASU.EDU
// 
//******************************************************************************
public abstract class Amphibian implements MakesSound {

}
