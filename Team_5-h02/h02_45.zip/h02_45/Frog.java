//******************************************************************************
// CLASS: Frog (Frog.Java)
//
// DESCRIPTION
// Frog is a subclass of Amphibian.
// 
// TEAM: 5
//
// AUTHORS:
//    ANDREW BRAND   | ABRAND3  | A.BRAND101691@YAHOO.COM
//    KENYON HUNDLEY | KHUNDLEY | KENYONHUNDLEY@YAHOO.COM
//    ISAIAH POTTS   | IPOTTS1  | ZAHPOTTS123@GMAIL.COM
//    ANTHONY SPAUGH | ASPAUGH  | ASPAUGH@ASU.EDU
// 
//******************************************************************************
public class Frog extends Amphibian  {
	
	@Override
	public void makeSound() {
		System.out.println("Ribbet");
	}

}
